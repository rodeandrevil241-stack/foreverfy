/**
 * Credential method tabs (Password / sp_dc cookie) used by upgrade.php and
 * renew.php. Mirrors the React CredentialsField on upgrader.cc.
 *
 * Expects the surrounding HTML structure:
 *
 *   <div id="credentialField" data-method="password">
 *     <div id="credTabs">
 *       <button class="cred-tab" data-method="password">…</button>
 *       <button class="cred-tab" data-method="sp_dc">…</button>
 *     </div>
 *     <div class="cred-panel" data-method="password">… #spotifyPassword …</div>
 *     <div class="cred-panel" data-method="sp_dc" hidden>
 *       … #spotifySpDc, #credHowToToggle, #credHowTo, #credSpDcDisabledNotice
 *     </div>
 *   </div>
 *
 * Active tab state is mirrored to #credentialField[data-method] so other
 * scripts (form submit handlers) can read it with getCredentialMethod().
 */

const SP_DC_PATTERN = /^[A-Za-z0-9_=-]+$/;
const SP_DC_MAX_LENGTH = 300;
const SP_DC_MIN_LENGTH = 50;

/**
 * Strip a pasted "sp_dc=" prefix and wrapping quotes/semicolons.
 */
function sanitizeSpDc(value) {
  if (!value) return '';
  let v = String(value).trim();
  if (v.toLowerCase().startsWith('sp_dc=')) v = v.slice(6);
  v = v.replace(/^["'\s;]+|["'\s;]+$/g, '');
  return v;
}

function validateSpDcValue(value) {
  const v = sanitizeSpDc(value);
  if (!v) return 'sp_dc cookie is required';
  if (v.length > SP_DC_MAX_LENGTH) return `sp_dc cookie is too long (max ${SP_DC_MAX_LENGTH} characters)`;
  if (v.length < SP_DC_MIN_LENGTH) return `sp_dc cookie is too short (min ${SP_DC_MIN_LENGTH} characters)`;
  if (!SP_DC_PATTERN.test(v)) return 'sp_dc cookie contains invalid characters. Only letters, numbers, _, -, = are allowed.';
  return null;
}

function getCredentialMethod() {
  const root = document.getElementById('credentialField');
  return (root && root.dataset.method) || 'password';
}

function setCredentialMethod(method) {
  const root = document.getElementById('credentialField');
  if (!root) return;
  const next = method === 'sp_dc' ? 'sp_dc' : 'password';
  root.dataset.method = next;

  root.querySelectorAll('.cred-tab').forEach((btn) => {
    const isActive = btn.dataset.method === next;
    btn.setAttribute('aria-selected', isActive ? 'true' : 'false');
    if (isActive) {
      btn.style.background = btn.dataset.method === 'sp_dc'
        ? 'var(--color-primary)'
        : 'white';
      btn.style.color = btn.dataset.method === 'sp_dc'
        ? 'white'
        : 'var(--color-neutral-900)';
      btn.style.boxShadow = 'var(--shadow-sm)';
    } else {
      btn.style.background = 'transparent';
      btn.style.color = 'var(--color-neutral-700)';
      btn.style.boxShadow = 'none';
    }
  });

  root.querySelectorAll('.cred-panel').forEach((panel) => {
    panel.hidden = panel.dataset.method !== next;
  });

  // Required-attribute juggling: only the active panel's input is required.
  const pwd = document.getElementById('spotifyPassword');
  const spDc = document.getElementById('spotifySpDc');
  if (pwd) pwd.required = next === 'password';
  if (spDc) spDc.required = next === 'sp_dc';

  // Hide sibling form-groups marked with `data-cred-hidden-when="<method>"`.
  // Used to drop the login field in cookie mode since the worker discovers
  // the email from sp_dc after authenticating.
  document.querySelectorAll('[data-cred-hidden-when]').forEach((el) => {
    const hideWhen = el.getAttribute('data-cred-hidden-when');
    if (hideWhen === next) {
      el.hidden = true;
      el.querySelectorAll('input,select,textarea').forEach((field) => {
        field.disabled = true;
      });
    } else {
      el.hidden = false;
      el.querySelectorAll('input,select,textarea').forEach((field) => {
        field.disabled = false;
      });
    }
  });
}

function initCredentialField() {
  const root = document.getElementById('credentialField');
  if (!root) return;

  // Wire up tab clicks.
  root.querySelectorAll('.cred-tab').forEach((btn) => {
    btn.addEventListener('click', () => setCredentialMethod(btn.dataset.method));
  });

  // How-to expander.
  const howToBtn = document.getElementById('credHowToToggle');
  const howTo = document.getElementById('credHowTo');
  if (howToBtn && howTo) {
    howToBtn.addEventListener('click', () => {
      const open = !howTo.hidden;
      howTo.hidden = open;
      howToBtn.setAttribute('aria-expanded', open ? 'false' : 'true');
    });
  }

  // Default to password method (server enforces the rule anyway).
  setCredentialMethod('password');

  // Local toggle: each reseller can disable the cookie path independently of
  // the central upgrader.cc admin. Stored under CONFIG.flags.spDcEnabled.
  // Default ON when undefined.
  const localEnabled = !(typeof CONFIG !== 'undefined'
    && CONFIG.flags
    && CONFIG.flags.spDcEnabled === false);

  if (!localEnabled) {
    hideSpDcTab('Cookie authentication is disabled for this site.');
    return;
  }

  // Central toggle: ask upgrader.cc whether the cookie path is admin-disabled
  // globally. Central disable always wins. Fail-open on fetch error (server
  // rejects the field downstream if it's actually disabled).
  fetchFeaturesAndApplySpDcGate();
}

function hideSpDcTab(message) {
  setCredentialMethod('password');
  const tabs = document.getElementById('credTabs');
  if (tabs) tabs.hidden = true;
  const spDcPanel = document.querySelector('.cred-panel[data-method="sp_dc"]');
  if (spDcPanel) spDcPanel.hidden = true;
  const notice = document.getElementById('credSpDcDisabledNotice');
  if (notice && message) {
    notice.textContent = message;
    notice.hidden = false;
  }
}

async function fetchFeaturesAndApplySpDcGate() {
  try {
    const basePath = typeof getApiBasePath === 'function' ? getApiBasePath() : './api';
    const res = await fetch(`${basePath}/proxy.php?endpoint=features`, {
      method: 'GET',
      headers: { 'Accept': 'application/json' },
    });
    if (!res.ok) return;
    const data = await res.json();
    const sp = data && data.features && data.features.sp_dc;
    if (!sp || !sp.disabled) return;

    hideSpDcTab(sp.message || 'Cookie authentication is temporarily disabled.');
  } catch (_e) {
    // Fail open.
  }
}

// Expose for inline form-submit handlers.
window.sanitizeSpDc = sanitizeSpDc;
window.validateSpDcValue = validateSpDcValue;
window.getCredentialMethod = getCredentialMethod;
window.setCredentialMethod = setCredentialMethod;
window.initCredentialField = initCredentialField;
